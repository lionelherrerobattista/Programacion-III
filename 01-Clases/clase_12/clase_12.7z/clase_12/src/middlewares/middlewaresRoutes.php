<?php

use App\Models\ORM\usuario;

require_once __DIR__ . "/../../src/app/modelORM/usuario.php";

class Middleware
{
    function validarUsuario($request, $resposne, $next)
    {
        $email = $request->getParam("email");
        $clave = $request->getParam("clave");

        //Busco al usuario por email en la base de datos:
        $usuario = usuario::where('email', $email)->first();

        //Compruebo la clave:
        $response = $next($request, $response);
        if(hash_equals($usuario->clave, crypt($clave, "aaa"))) //generar salt 2do parametro igual al anterior
        {
        }
        else
        {
        $newResponse = $response->withJson("No existe $email", 200);
        }
    }
}
    
?>