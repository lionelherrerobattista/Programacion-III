<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\usuario;
use App\Models\ORM\usuarioControler;


include_once __DIR__ . '/../../src/app/modelORM/usuario.php';
include_once __DIR__ . '/../../src/app/modelORM/usuarioControler.php';
include_once __DIR__ . '/../../src/middlewares/middlewaresRoutes.php';

return function (App $app) {
    $container = $app->getContainer();

     $app->group('/usuarioORM', function () {   

        $this->get('/',usuarioControler::class . ':traerTodos');

        $this->post('/agregar', usuarioControler::class . ':cargarUno');
        
        $this->get('/login', usuarioControler::class . ':loginUsuario')->add(function ($req, $res, $next) {
            
            $email = $req->getParam("email");
            $clave = $req->getParam("clave");

            //Busco al usuario por email en la base de datos:
            $usuario = usuario::where('email', $email)->first();

            //Compruebo la clave:
            $response = $next($req, $res);
            if(hash_equals($usuario->clave, crypt($clave, "aaa"))) //generar salt 2do parametro igual al anterior
            {
            }
            else
            {
            $newResponse = $res->withJson("No existe $email", 200);
            }
        } );
   
    });

};